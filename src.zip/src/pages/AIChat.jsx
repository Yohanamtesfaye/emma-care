"use client"

import { useState, useRef, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import { ArrowLeft, Send, Bot, User, MessageCircle, Baby, Stethoscope, Loader } from "lucide-react"
import aiEngine from "../utils/aiEngine"

const API_BASE_URL = "http://localhost:3000"

const AIChat = ({ user, userRole, onLogout }) => {
  const navigate = useNavigate()
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "Hello! I'm your AI health assistant. I can answer questions about your measured vital signs and provide general pregnancy advice. How can I assist you today?",
      sender: "ai",
      timestamp: new Date(),
    },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [vitals, setVitals] = useState(null)
  const messagesEndRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
    const fetchVitals = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/api/data`)
        if (response.ok) {
          const data = await response.json()
          if (data && data.length > 0) {
            const latest = data[0]
            setVitals({
              heart_rate: latest.heart_rate,
              spo2: latest.spo2,
              temperature: latest.temperature,
              systolic: latest.blood_pressure,
            })
          }
        }
      } catch (err) {
        console.error('Failed to fetch vitals for AI Chat:', err)
      }
    }

    fetchVitals()
    const interval = setInterval(fetchVitals, 5000)
    return () => clearInterval(interval)
  }, [])

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return

    const userMessage = {
      id: Date.now(),
      text: inputMessage,
      sender: "user",
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")
    setIsLoading(true)

    setTimeout(() => {
      const aiResponseText = aiEngine.generateResponse(inputMessage, vitals)
      
      const aiMessage = {
        id: Date.now() + 1,
        text: aiResponseText,
        sender: "ai",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, aiMessage])
      setIsLoading(false)
    }, 1000)
  }

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const quickQuestions = [
    "Is my heart rate normal?",
    "Check my oxygen level",
    "How is my temperature?",
    "What about my blood pressure?",
    "Advice on nutrition",
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <header className="bg-white/80 backdrop-blur-sm shadow-sm border-b sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <button
                onClick={() => navigate(userRole === "patient" ? "/patient" : "/doctor")}
                className="p-2 hover:bg-gray-100 rounded-full mr-3 transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-gray-600" />
              </button>
              <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-1.5 rounded-lg mr-2">
                <MessageCircle className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-800">AI Health Assistant</h1>
                <p className="text-xs text-gray-600">Get guidance based on your vitals</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <div className="flex items-center">
                <div className="bg-gradient-to-r from-pink-500 to-purple-600 p-1 rounded-lg mr-1">
                  {userRole === "patient" ? (
                    <Baby className="w-3 h-3 text-white" />
                  ) : (
                    <Stethoscope className="w-3 h-3 text-white" />
                  )}
                </div>
                <span className="text-xs text-gray-600 capitalize">{userRole}</span>
              </div>
              <button
                onClick={onLogout}
                className="bg-gray-100 hover:bg-gray-200 px-3 py-1.5 rounded-lg text-gray-700 transition-colors text-sm"
              >
                Exit
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-4 h-[calc(100vh-80px)] flex flex-col">
        <div className="flex-1 bg-white rounded-xl shadow-sm border overflow-hidden flex flex-col">
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`flex items-start space-x-2 max-w-[80%] ${message.sender === "user" ? "flex-row-reverse space-x-reverse" : ""}`}
                >
                  <div className={`p-2 rounded-full ${message.sender === "user" ? "bg-purple-100" : "bg-blue-100"}`}>
                    {message.sender === "user" ? (
                      <User className="w-4 h-4 text-purple-600" />
                    ) : (
                      <Bot className="w-4 h-4 text-blue-600" />
                    )}
                  </div>
                  <div
                    className={`p-3 rounded-lg ${
                      message.sender === "user" ? "bg-purple-500 text-white" : "bg-gray-100 text-gray-800"
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                    <p className={`text-xs mt-1 ${message.sender === "user" ? "text-purple-200" : "text-gray-500"}`}>
                      {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>
              </div>
            ))}

            {isLoading && (
              <div className="flex justify-start">
                <div className="flex items-start space-x-2 max-w-[80%]">
                  <div className="p-2 rounded-full bg-blue-100">
                    <Bot className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="bg-gray-100 text-gray-800 p-3 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Loader className="w-4 h-4 animate-spin text-blue-600" />
                      <p className="text-sm">AI is thinking...</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {messages.length < 3 && (
            <div className="p-4 border-t bg-gray-50">
              <p className="text-sm font-medium text-gray-700 mb-2">Quick questions:</p>
              <div className="flex flex-wrap gap-2">
                {quickQuestions.map((question, index) => (
                  <button
                    key={index}
                    onClick={() => setInputMessage(question)}
                    className="text-xs bg-white hover:bg-blue-50 text-blue-600 px-3 py-1.5 rounded-full border border-blue-200 transition-colors"
                  >
                    {question}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="p-4 border-t bg-white">
            <div className="flex space-x-2">
              <textarea
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask about your vital signs or general pregnancy topics..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm resize-none"
                rows="2"
                disabled={isLoading}
              />
              <button
                onClick={handleSendMessage}
                disabled={!inputMessage.trim() || isLoading}
                className="bg-blue-500 hover:bg-blue-600 disabled:bg-gray-300 text-white p-2 rounded-lg transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              💡 This AI assistant provides general information based on your sensor data. Always consult your healthcare provider for medical advice.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}

export default AIChat
